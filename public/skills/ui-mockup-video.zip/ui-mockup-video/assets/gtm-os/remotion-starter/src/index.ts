import {registerRoot} from 'remotion';
import '@fontsource/inter/400.css';
import '@fontsource/inter/600.css';
import '@fontsource/inter/700.css';
import {Root} from './Root';

registerRoot(Root);
